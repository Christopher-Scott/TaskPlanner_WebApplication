var sampleData1 = [
            {
                    "image" : "",
                    "userEmail" : "bob@gmail.com",
                    "taskTitle" : "Walk Fido",
                    "taskDesc" : "Fido needs his walkies",
                    "dueDate" : "11/01/2020"             
            },
            {
                    "image" : "",
                    "userEmail" : "alice@yahoo.com",
                    "taskTitle" : "Calc HW",
                    "taskDesc" : "",
                    "dueDate" : "11/20/2020"
            },			
            {
                    "image" : "pics/task_64.png",
                    "userEmail" : "richard@temple.edu",
                    "taskTitle" : "Web Application HW",
                    "taskDesc" : "Complete LA",
                    "dueDate" : "11/17/2020"

            },		
            {
                    "image" : "pics/cal_64.png",
                    "userEmail" : "alice@yahoo.com",
                    "taskTitle" : "Phys Exam",
                    "taskDesc" : "",
                    "dueDate" : "12/09/2020"
            },
            {
                    "userEmail" : "alice@yahoo.com",
                    "taskTitle" : "Calc Quiz",
                    "taskDesc" : "",
                    "dueDate" : "10/21/2020"
            },
            {                    
                    "image" : "pics/cal_64.png",
                    "userEmail" : "alice@yahoo.com",
                    "taskTitle" : "VOTE!",
                    "taskDesc" : "",
                    "dueDate" : "11/03/2020"
            },
            {                    
                    "image" : "pics/wrench_64.png",
                    "userEmail" : "richard@temple.edu",
                    "taskTitle" : "Rake the Leaves",
                    "taskDesc" : "",
                    "dueDate" : "10/08/2020"
            },
            {                    
                    "image" : "pics/cal_64.png",
                    "userEmail" : "richard@temple.edu",
                    "taskTitle" : "Start Christmas shopping",
                    "taskDesc" : "",
                    "dueDate" : "12/04/2020"
            },
            {                    
                    "image" : "pics/food_64.png",
                    "userEmail" : "bob@gmail.edu",
                    "taskTitle" : "Buy a Turkey",
                    "taskDesc" : "",
                    "dueDate" : "11/12/2020"
            }
        ];