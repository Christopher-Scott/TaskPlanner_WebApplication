var sampleData2 = [
                {
                    date: "10/01/2020", 
                    data: "Halloween Decorations", 
                    detail: "Skeleton, Cobwebs, Bats", 
                    image: "pics/home_64.png"
                },
                {
                    date: "10/21/2020", 
                    data: "House Party", 
                    detail: "Send out invites", 
                    image: "pics/home_64.png"
                },
                {
                    date: "10/11/2020", 
                    data: "Put gas in Car", 
                    detail: "Running Empty", 
                    image: "pics/car_64.png"
                },
                {
                    date: "10/08/2020", 
                    data: "Doctor's Appointment", 
                    detail: "Get a flu shot", 
                    image: "pics/cal_64.png"
                },
                {
                    date: "10/08/2020", 
                    data: "Finish Tutorial", 
                    detail: "It's done",
                    image: "pics/task_64.png"
                }
            ];